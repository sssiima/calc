﻿using System;

namespace ConsoleApp1
{
    public interface IGraphics
    {
        double Calculate(double x, int roundValue);
        bool GetGraphics(IGraphics f, double x1, double x2, ref double x);
    }

    public class Fx1 : IGraphics
    {
        public double Calculate(double x, int roundValue)
        {
            return Math.Round(2 * Math.Sin(x / 2 + 3), roundValue);
        }

        public bool GetGraphics(IGraphics f, double x1, double x2, ref double x_cross)
        {
            double x;
            for (x = x1; x <= x2; x += 0.0001)
            {
                if (Calculate(x, 2) != f.Calculate(x, 2)) continue;
                x_cross = x;
                return true;
            }

            return false;
        }
    }

    public class Gx1 : IGraphics
    {
        public double Calculate(double x, int roundValue)
        {
            return Math.Round(1.5 * Math.Pow(x, 2) - 2.5 * x - 4, roundValue);
        }

        public bool GetGraphics(IGraphics g, double x1, double x2, ref double x_cross)
        {
            double x;
            for (x = x1; x <= x2; x += 0.0001)
                if (Calculate(x, 2) == g.Calculate(x, 2))
                {
                    x_cross = x;
                    return true;
                }

            return false;
        }
    }

    internal class Program
    {
        
        

        private static void Main(string[] args)
        {
            IGraphics fx1 = new Fx1();
            IGraphics gx1 = new Gx1();

            double x1 = 0, x2 = 0, length = 0;
            if (fx1.GetGraphics(gx1, -5, 0, ref x1))
            {
                Console.WriteLine($"x1 = {Math.Round(x1, 3)}; y1 = {Math.Round(fx1.Calculate(x1, 3), 3)}");
                if (fx1.GetGraphics(gx1, 0, 4, ref x2))
                {
                    Console.WriteLine($"x2 = {Math.Round(x2, 3)}; y2 = {Math.Round(gx1.Calculate(x2, 3), 3)}");
                }
            }

            Console.WriteLine($"First dot: q1({Math.Round(x1, 3)}; {Math.Round(fx1.Calculate(x1, 3), 3)})");
            Console.WriteLine($"Second dot: q2({Math.Round(x2, 3)}; {Math.Round(gx1.Calculate(x2, 3), 3)})");
            length = Math.Sqrt((x2 - x1) * (x2 - x1) +
                            (Math.Round(fx1.Calculate(x1, 3), 3) - Math.Round(gx1.Calculate(x2, 3)) *
                            (Math.Round(fx1.Calculate(x1, 3), 3) - Math.Round(gx1.Calculate(x2, 3)))));
            Console.WriteLine($"Length [a;b]: {Math.Round(length, 3)}");
            Console.ReadKey(true);
        }
    }
}