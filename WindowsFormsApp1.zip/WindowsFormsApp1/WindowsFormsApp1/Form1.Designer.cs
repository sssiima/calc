﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.input_TB = new System.Windows.Forms.TextBox();
            this.output_TB = new System.Windows.Forms.TextBox();
            this.compile_BTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // input_TB
            // 
            this.input_TB.Location = new System.Drawing.Point(16, 15);
            this.input_TB.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.input_TB.Multiline = true;
            this.input_TB.Name = "input_TB";
            this.input_TB.Size = new System.Drawing.Size(632, 262);
            this.input_TB.TabIndex = 0;
            // 
            // output_TB
            // 
            this.output_TB.Location = new System.Drawing.Point(16, 286);
            this.output_TB.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.output_TB.Multiline = true;
            this.output_TB.Name = "output_TB";
            this.output_TB.Size = new System.Drawing.Size(632, 262);
            this.output_TB.TabIndex = 1;
            // 
            // compile_BTN
            // 
            this.compile_BTN.Location = new System.Drawing.Point(657, 15);
            this.compile_BTN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.compile_BTN.Name = "compile_BTN";
            this.compile_BTN.Size = new System.Drawing.Size(268, 90);
            this.compile_BTN.TabIndex = 2;
            this.compile_BTN.Text = "Compile and run";
            this.compile_BTN.UseVisualStyleBackColor = true;
            this.compile_BTN.Click += new System.EventHandler(this.compile_BTN_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(935, 570);
            this.Controls.Add(this.compile_BTN);
            this.Controls.Add(this.output_TB);
            this.Controls.Add(this.input_TB);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox input_TB;
        private System.Windows.Forms.TextBox output_TB;
        private System.Windows.Forms.Button compile_BTN;
    }
}

