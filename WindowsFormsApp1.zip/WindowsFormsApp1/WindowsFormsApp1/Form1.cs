﻿using Microsoft.CSharp;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void compile_BTN_Click(object sender, EventArgs e)
        {
            var driver = new CodeProvider();
            bool isError;
            output_TB.Text = driver.Compile(input_TB.Text, out isError);
            if(isError) output_TB.BackColor = Color.Red;
            else output_TB.BackColor = Color.Green;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }

    public class CodeProvider
    {
        private string prefix = "using System;" + "public static class Driver" + "{" +
            "public static void Run()" + "{";
        private string postfix = "}" + "}";

        public string Compile(string input, out bool hasError)
        {
            hasError = false;
            string returnData = null;
            CompilerResults results = null;
            using (var provider = new CSharpCodeProvider())
            {
                var options = new CompilerParameters();
                options.GenerateInMemory = true;
                var sb = new StringBuilder();
                sb.Append(prefix);
                sb.Append(input);
                sb.Append(postfix);
                results = provider.CompileAssemblyFromSource(options, sb.ToString());
            }
            if (results.Errors.HasErrors)
            {
                hasError = true;
                var errorMSG = new StringBuilder();
                foreach (CompilerError error in results.Errors)
                {
                    errorMSG.AppendFormat("{0} {1}", error.Line, error.ErrorText);
                }
                returnData = errorMSG.ToString();
            }
            else
            {
                TextWriter temp = Console.Out;
                var writer = new StringWriter();
                Console.SetOut(writer);
                Type driverType = results.CompiledAssembly.GetType("Driver");
                driverType.InvokeMember("Run", System.Reflection.BindingFlags.InvokeMethod | System.Reflection.BindingFlags.Static |
                    System.Reflection.BindingFlags.Public, null, null, null);
                Console.SetOut(temp);
                returnData = writer.ToString();
            }
            return $"hello my app results are:\r\n\r\n{returnData}\r\n" +
                   $"all work was done";
        }
    }

}
