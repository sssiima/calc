﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Component1 : Button
    {

        public Component1()
        {
            InitializeComponent();
            Init();
        }

        public Component1(IContainer container)
        {
            container.Add(this);
            InitializeComponent();
            Init();
        }
        // default settings
        private void Init()
        {
            this.SetStyle(ControlStyles.UserPaint, true); // мы будем рисовать компонент, а не ОС
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true); // убираем нежелательное мерцание
            this.Margin = new Padding(this.Font.Height); // наружный отступ по контуру кнопки
            this.AutoSize = true; // авторазмер под размер надписи внутри кнопки
        }

        protected override void OnResize(EventArgs e)
        {
            GraphicsPath path = new GraphicsPath();
            path.AddEllipse(this.ClientRectangle);
            this.Region = new System.Drawing.Region(path);
            base.OnResize(e);
        }

        protected override void OnPaint(PaintEventArgs pevent)
        {
            Graphics graphics = pevent.Graphics;
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            bool isPressed = this.Capture & Control.MouseButtons != 0 & this.ClientRectangle.Contains(this.PointToClient(Control.MousePosition));
            Rectangle rect = this.ClientRectangle;
            GraphicsPath path = new GraphicsPath();
            path.AddEllipse(rect);
            PathGradientBrush gradientBrush = new PathGradientBrush(path);
            int key = isPressed ? 2 : 1;
            gradientBrush.CenterPoint = new PointF(key * (rect.Left + rect.Right) / 3, key * (rect.Top + rect.Bottom) / 3);
            gradientBrush.CenterColor = isPressed ? Color.AliceBlue : Color.White;
            gradientBrush.SurroundColors = new Color[] { Color.Blue };
            graphics.FillEllipse(gradientBrush, rect);

            Brush brush = new LinearGradientBrush(rect, Color.FromArgb(0, 0, 255), Color.FromArgb(0, 0, 100), LinearGradientMode.ForwardDiagonal);
            Pen pen = new Pen(brush, (this.IsDefault ? 3 : 1) * graphics.DpiX / 72);
            graphics.DrawEllipse(pen, rect);    
            StringFormat stringFormat = new StringFormat();
            stringFormat.Alignment = stringFormat.LineAlignment = StringAlignment.Center;
            brush = this.Enabled ? SystemBrushes.WindowText : SystemBrushes.GrayText;
            graphics.DrawString(this.Text, this.Font, brush, rect, stringFormat);
            if (this.Focused)
            {
                SizeF sizeF = graphics.MeasureString(this.Text, this.Font, PointF.Empty, StringFormat.GenericTypographic);
                pen = new Pen(this.ForeColor);
                pen.DashStyle = DashStyle.Dash;
                graphics.DrawRectangle(pen, rect.Left + rect.Width / 2 - sizeF.Width / 2, rect.Top + rect.Bottom / 2 - sizeF.Height / 2, sizeF.Width, sizeF.Height);
            }
            else
            {
                pen.Width = 12;
                graphics.DrawEllipse(pen, rect);
            }
        }
        new public event PaintEventHandler Paint;
    }
}
