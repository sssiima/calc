﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        private void component11_MouseDown(object sender, MouseEventArgs e)
        {

            Component1 bnt = sender as Component1;
            if (bnt != null)
            {
                label1.Text = $"Press button: {bnt.Name} with mouse {e.Button}";
            }
        }
    }
}
