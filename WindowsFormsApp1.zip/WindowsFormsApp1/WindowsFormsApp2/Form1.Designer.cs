﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.component12 = new WindowsFormsApp2.Component1(this.components);
            this.component11 = new WindowsFormsApp2.Component1(this.components);
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(29, 452);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // component12
            // 
            this.component12.AutoSize = true;
            this.component12.Location = new System.Drawing.Point(625, 95);
            this.component12.Margin = new System.Windows.Forms.Padding(17, 16, 17, 16);
            this.component12.Name = "component12";
            this.component12.Size = new System.Drawing.Size(301, 277);
            this.component12.TabIndex = 3;
            this.component12.Text = "component12";
            this.component12.UseVisualStyleBackColor = true;
            this.component12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.component11_MouseDown);
            // 
            // component11
            // 
            this.component11.AutoSize = true;
            this.component11.Location = new System.Drawing.Point(124, 43);
            this.component11.Margin = new System.Windows.Forms.Padding(17, 16, 17, 16);
            this.component11.Name = "component11";
            this.component11.Size = new System.Drawing.Size(436, 379);
            this.component11.TabIndex = 2;
            this.component11.Text = "component11";
            this.component11.UseVisualStyleBackColor = true;
            this.component11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.component11_MouseDown);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(956, 618);
            this.Controls.Add(this.component12);
            this.Controls.Add(this.component11);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private Component1 component11;
        private Component1 component12;
    }
}

